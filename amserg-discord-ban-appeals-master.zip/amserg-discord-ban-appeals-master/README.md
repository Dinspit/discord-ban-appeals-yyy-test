# Дискорд Разбаны для AmSerg Games

![image](https://github.com/Dinspit/amserg-discord-ban-appeals/assets/91454173/30ac7df4-ef7c-489f-a60f-c44dec39c064)




